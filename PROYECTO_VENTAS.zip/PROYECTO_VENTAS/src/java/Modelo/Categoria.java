/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.UUID;

/**
 *
 * @author USUARIO
 */
public class Categoria {
    private String Id;
    private String Categ;
    private int Estado;

    public Categoria() {
        this.Id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0, 4);
    }

    public Categoria(String Categ, int Estado) {
        this.Id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0, 4);
        this.Categ = Categ;
        this.Estado = Estado;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getCateg() {
        return Categ;
    }

    public void setCateg(String Categ) {
        this.Categ = Categ;
    }

    public int getEstado() {
        return Estado;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }
    
    
}
