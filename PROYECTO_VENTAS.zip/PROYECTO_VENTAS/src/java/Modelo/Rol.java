/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.UUID;

/**
 *
 * @author USUARIO
 */
public class Rol {
    private String Id;
    private String Rol;
    private int Estado;

    public Rol() {
        this.Id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0, 3);
    }

    public Rol(String Rol, int Estado) {
        this.Id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0, 3);
        this.Rol = Rol;
        this.Estado = Estado;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getRol() {
        return Rol;
    }

    public void setRol(String Rol) {
        this.Rol = Rol;
    }

    public int getEstado() {
        return Estado;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }
    
    
}
