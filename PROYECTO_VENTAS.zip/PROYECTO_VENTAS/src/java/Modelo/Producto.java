/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.UUID;
//robo
//accidente
//documentacion
//puedo hacer algo ahorita? o tengo que tener la mobilidad
//cuanto es al año
//costos...mensual
//si tengo un robo, o un accidente...el seguro me reconoce algo? que cantidad, y a que tiempo.
/**
 *
 * @author USUARIO
 */
public class Producto {
    private String Id;
    private String Nombre;
    private String Des;
    private Double Pre;
    private Categoria categoria;
    private int Stock;
    private int Estado;

    public Producto() {
        this.Id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0, 6);
    }

    public Producto(String Nombre, String Des, Double Pre, Categoria categoria, int Stock, int Estado) {
        this.Id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0, 6);
        this.Nombre = Nombre;
        this.Des = Des;
        this.Pre = Pre;
        this.categoria = categoria;
        this.Stock = Stock;
        this.Estado = Estado;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDes() {
        return Des;
    }

    public void setDes(String Des) {
        this.Des = Des;
    }

    public Double getPre() {
        return Pre;
    }

    public void setPre(Double Pre) {
        this.Pre = Pre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    public int getEstado() {
        return Estado;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }
    
}
