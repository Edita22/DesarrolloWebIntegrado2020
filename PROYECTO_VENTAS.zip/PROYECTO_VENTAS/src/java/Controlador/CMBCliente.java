/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import GestorDB.*;
import Modelo.*;
import java.util.ArrayList;
import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 *
 * @author USUARIO
 */
@Named(value = "cMBCliente")
@Dependent
public class CMBCliente {
    private ArrayList<Cliente> lis;
    public ArrayList<Cliente> getLis(){
         return lis;
     }
    public CMBCliente() throws Exception  {
        GDBCliente obj= new GDBCliente();
        lis=obj.listar();
    }
    
}
