/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import GestorDB.*;
import Modelo.*;
import java.util.ArrayList;
import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 *
 * @author USUARIO
 */
@Named(value = "cMBCategoria")
@Dependent
public class CMBCategoria {
    private ArrayList<Categoria> lis;
    public ArrayList<Categoria> getLis(){
         return lis;
     }
    public CMBCategoria() throws Exception  {
        GDBCategoria obj= new GDBCategoria();
        lis=obj.listar();
    }
    
}
