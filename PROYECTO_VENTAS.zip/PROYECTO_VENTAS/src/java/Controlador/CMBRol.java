
package Controlador;

import GestorDB.*;
import Modelo.*;
import java.util.ArrayList;
import javax.inject.Named;
import javax.enterprise.context.Dependent;

@Named(value = "CMBRol")
@Dependent
public class CMBRol {
    private ArrayList<Rol> lis;
    public ArrayList<Rol> getLis(){
         return lis;
     }
    public CMBRol() throws Exception  {
        GDBRol obj= new GDBRol();
        lis=obj.listar();
    }
}
