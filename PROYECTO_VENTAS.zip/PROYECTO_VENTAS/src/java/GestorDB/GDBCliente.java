/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestorDB;

import Modelo.*;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class GDBCliente {
   public ArrayList<Cliente> listar() throws Exception{
        ArrayList<Cliente> lista=new ArrayList<Cliente>();
        Connection con=_Coneccion.getConexion();
        String sql="select * from cliente";
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        while(rs.next()){
            Cliente obj= new Cliente();
            obj.setDni(rs.getString(1));
            obj.setNom(rs.getString(2));
            obj.setAp(rs.getString(3));
            obj.setEstado(rs.getInt(4));
            lista.add(obj);
        }
        return lista;
   }
   public Cliente buscar(String dni) throws Exception{
        Connection con=_Coneccion.getConexion();
        String sql="select * from cliente where dni='"+dni+"'";
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        Cliente obj= new Cliente();
        while(rs.next()){
            obj.setDni(rs.getString(1));
            obj.setNom(rs.getString(2));
            obj.setAp(rs.getString(3));
            obj.setEstado(rs.getInt(4));
        }
        return obj;
   } 
}
