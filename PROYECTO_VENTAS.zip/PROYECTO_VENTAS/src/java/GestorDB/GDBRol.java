/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestorDB;

import Modelo.*;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class GDBRol {
    public ArrayList<Rol> listar() throws Exception{
        ArrayList<Rol> lista=new ArrayList<Rol>();
        Connection con=_Coneccion.getConexion();
        String sql="select * from Rol";
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        while(rs.next()){
            Rol obj= new Rol();
            obj.setId(rs.getString(1));
            obj.setRol(rs.getString(2));
            obj.setEstado(rs.getInt(3));
            lista.add(obj);
        }
        return lista;
    }
    public Rol buscar(String cod) throws Exception{
        Connection con=_Coneccion.getConexion();
        String sql="select * from Rol where ID='"+cod+"'";
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        Rol obj= new Rol();
        while(rs.next()){
            obj.setId(rs.getString(1));
            obj.setRol(rs.getString(2));
            obj.setEstado(rs.getInt(3));
        }
        return obj;
    }
}
