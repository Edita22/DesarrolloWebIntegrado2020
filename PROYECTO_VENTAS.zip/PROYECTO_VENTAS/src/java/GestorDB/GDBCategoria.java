/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestorDB;

import Modelo.*;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class GDBCategoria {
    public ArrayList<Categoria> listar() throws Exception{
        ArrayList<Categoria> lista=new ArrayList<Categoria>();
        Connection con=_Coneccion.getConexion();
        String sql="select * from Categoria";
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        while(rs.next()){
            Categoria obj= new Categoria();
            obj.setId(rs.getString(1));
            obj.setCateg(rs.getString(2));
            obj.setEstado(rs.getInt(3));
            lista.add(obj);
        }
        return lista;
    }
    public Categoria buscar(String cod) throws Exception{
        Connection con=_Coneccion.getConexion();
        String sql="select * from Categoria where ID='"+cod+"'";
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        Categoria obj= new Categoria();
        while(rs.next()){
            obj.setId(rs.getString(1));
            obj.setCateg(rs.getString(2));
            obj.setEstado(rs.getInt(3));
        }
        return obj;
    }
}
