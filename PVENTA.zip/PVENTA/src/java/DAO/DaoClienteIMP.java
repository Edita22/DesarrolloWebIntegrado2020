/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import GESTOR.Operación;
import LOGICA.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class DaoClienteIMP implements DaoCliente{

    @Override
    public String grabar(Clientes e) {
        return Operación.ejecutar("INSERT INTO cliente VALUES ('"+e.getDni()+"','"+e.getNombres()+"','"+e.getApellido()+"','"+e.getDirec()+"','"+e.getCorr()+"','"+e.getNumero()+"','"+e.getEstado()+"')");
    }

    @Override
    public String actualizar(Clientes e) {
        return Operación.ejecutar("UPDATE cliente SET NOMBRES='"+e.getNombres()+"',APELLIDOS='"+e.getApellido()+"',DIRECCION='"+e.getDirec()+"',CORREO='"+e.getCorr()+"',NUMEROTEL='"+e.getNumero()+"',ESTADO='"+e.getEstado()+"' WHERE DNI='"+e.getDni()+"'");
    }

    @Override
    public List listar1() {
        List lis = new ArrayList();
        List lista = Operación.listar("SELECT * FROM cliente");
        if(lista != null){
            for (int i = 1; i < lista.size(); i++) {
                Object[] fila = (Object[])lista.get(i);
                Clientes obj = new Clientes();
                obj.setDni(fila[0].toString());
                obj.setNombres(fila[1].toString());
                obj.setApellido(fila[2].toString());
                obj.setDirec(fila[3].toString());
                obj.setCorr(fila[4].toString());
                obj.setNumero(fila[5].toString());
                obj.setEstado(fila[6].toString());
                lis.add(obj);
            }
            return lis; 
        }
        return null; 
    }

    @Override
    public List listar2() {
        List lis = new ArrayList();
        List lista = Operación.listar("SELECT * FROM cliente WHERE cliente.ESTADO='0'");
        if(lista != null){
            for (int i = 1; i < lista.size(); i++) {
                Object[] fila = (Object[])lista.get(i);
                Clientes obj = new Clientes();
                obj.setDni(fila[0].toString());
                obj.setNombres(fila[1].toString());
                obj.setApellido(fila[2].toString());
                obj.setDirec(fila[3].toString());
                obj.setCorr(fila[4].toString());
                obj.setNumero(fila[5].toString());
                obj.setEstado(fila[6].toString());
                lis.add(obj);
            }
            return lis; 
        }
        return null; 
    }

    @Override
    public Clientes buscar(String cod) {
        Object[]fila = Operación.buscar("SELECT * FROM cliente where dni='"+cod+"'");
        if (fila!=null) {
            Clientes obj = new Clientes();
                obj.setDni(fila[0].toString());
                obj.setNombres(fila[1].toString());
                obj.setApellido(fila[2].toString());
                obj.setDirec(fila[3].toString());
                obj.setCorr(fila[4].toString());
                obj.setNumero(fila[5].toString());
                obj.setEstado(fila[6].toString());
            return obj;
        }
        return null; 
    }
    
}
