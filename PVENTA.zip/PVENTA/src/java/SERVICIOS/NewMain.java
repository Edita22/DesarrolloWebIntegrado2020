/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERVICIOS;
import DAO.*;
import LOGICA.*;
/**
 *
 * @author USUARIO
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        SerRol ser = new SerRolIMP();
//        System.out.println(ser.grabarRoles("ej2", "0"));
        Roles obj = new Roles();
        System.out.println(obj.getId());
    }
    
}
