/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERVICIOS;

import LOGICA.*;

/**
 *
 * @author USUARIO
 */
public interface SerUsuario {
    public Usuarios buscarUsuario(String cod);
    public String grabarUsuario(String nom, String ap, String us, String cont, String rol,String es);
    public String actualizarUsuario(String cod, String rol,String es);
    public Usuarios validarempleado(String usuario,String contrasena);
}
