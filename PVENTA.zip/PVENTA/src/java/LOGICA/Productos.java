/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LOGICA;

import java.util.UUID;

/**
 *
 * @author USUARIO
 */
public class Productos {
    private String id;
    private String nombre;
    private String descri;
    private double precio;
    private Categoria Categoria;
    private int stock;
    private byte[] FOTO;
    private String estado;

    public Productos() {
        this.id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0,6);
    }

    public Productos(String nombre, String descri, double precio, Categoria Categoria, int stock, byte[] FOTO, String estado) {
        this.id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0,6);
        this.nombre = nombre;
        this.descri = descri;
        this.precio = precio;
        this.Categoria = Categoria;
        this.stock = stock;
        this.FOTO = FOTO;
        this.estado = estado;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescri() {
        return descri;
    }

    public void setDescri(String descri) {
        this.descri = descri;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Categoria getCategoria() {
        return Categoria;
    }

    public void setCategoria(Categoria Categoria) {
        this.Categoria = Categoria;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public byte[] getFOTO() {
        return FOTO;
    }

    public void setFOTO(byte[] FOTO) {
        this.FOTO = FOTO;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
