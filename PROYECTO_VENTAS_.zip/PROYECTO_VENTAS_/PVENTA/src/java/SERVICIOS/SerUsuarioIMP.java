/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERVICIOS;

import LOGICA.*;
import DAO.*;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class SerUsuarioIMP implements SerUsuario{
    private DaoUsuario DaoUsuario;
    

    public SerUsuarioIMP() {
        DaoUsuario=new DaoUsuarioIMP(); 
    }
    
    @Override
    public Usuarios buscarUsuario(String cod) {
        return DaoUsuario.buscar(cod);
    }

    @Override
    public String grabarUsuario(String nom, String ap, String us, String cont, String rol, String es) {
        DaoRol daorol = new DaoRolIMP();
        Usuarios x = new Usuarios(nom, ap, us, cont,daorol.buscar(rol) , es);
        return DaoUsuario.grabar(x);
    }

    @Override
    public String actualizarUsuario(String cod, String rol, String es) {
        DaoRol daorol = new DaoRolIMP();
        Usuarios x = new Usuarios(null, null, null, null,daorol.buscar(rol) , es);
        x.setId(cod);
        return DaoUsuario.actualizar(x);
    }

    @Override
    public Usuarios validarempleado(String usuario, String contrasena) {
        List lista = DaoUsuario.listar2();
        if (lista!=null) {
            for (int i = 0; i < lista.size(); i++) {
                Usuarios e = (Usuarios) lista.get(i);
                if (e.getUsuario().equals(usuario) && e.getContra().equals(contrasena)) {
                    return e;
                }
            }
        }
        return null;
    }
    
}
