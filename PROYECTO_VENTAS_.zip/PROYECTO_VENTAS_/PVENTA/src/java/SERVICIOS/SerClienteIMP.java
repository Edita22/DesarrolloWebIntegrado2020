/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERVICIOS;

import DAO.*;
import LOGICA.*;

/**
 *
 * @author USUARIO
 */
public class SerClienteIMP implements SerCliente{
    private DaoCliente daocli = new DaoClienteIMP();
    @Override
    public Clientes buscarClientes(String dni) {
        return daocli.buscar(dni);
    }
@Override
    public String grabarClientes(String dni,String nom, String ap, String dir, String cor, String num, String estado) {
        Clientes obj = new Clientes(dni, nom, ap, dir, cor, num, estado);
        return daocli.grabar(obj);
    }

    @Override
    public String actualizarClientes(String dni, String nom, String ap, String dir, String cor, String num, String estado) {       
        Clientes obj = new Clientes(dni, nom, ap, dir, cor, num, estado);
        return daocli.actualizar(obj);
    }

}
