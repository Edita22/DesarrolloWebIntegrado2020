/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LOGICA;

import java.util.UUID;

/**
 *
 * @author USUARIO
 */
public class Usuarios {
    private String id,nombres,apellidos,usuario,contra;
    private Roles rol;
    private String estado;

    public Usuarios() {
    }

    public Usuarios(String nombres, String apellidos, String usuario, String contra, Roles rol, String estado) {
        this.id = ""+UUID.randomUUID().toString().toUpperCase().subSequence(0,4);
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.usuario = usuario;
        this.contra = contra;
        this.rol = rol;
        this.estado = estado;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public Roles getRol() {
        return rol;
    }

    public void setRol(Roles rol) {
        this.rol = rol;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
