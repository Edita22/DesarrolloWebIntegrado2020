-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-10-2020 a las 22:26:03
-- Versión del servidor: 10.4.13-MariaDB
-- Versión de PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_desarrollo`
--
CREATE DATABASE IF NOT EXISTS `bd_desarrollo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bd_desarrollo`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE `categoria` (
  `ID` char(4) NOT NULL,
  `CATEGORIA` varchar(15) NOT NULL,
  `ESTADO` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`ID`, `CATEGORIA`, `ESTADO`) VALUES('5A07', 'Limpieza', '0');
INSERT INTO `categoria` (`ID`, `CATEGORIA`, `ESTADO`) VALUES('C8F3', 'Comida', '0');
INSERT INTO `categoria` (`ID`, `CATEGORIA`, `ESTADO`) VALUES('D8F5', 'Higuiene', '1');
INSERT INTO `categoria` (`ID`, `CATEGORIA`, `ESTADO`) VALUES('DFGT', 'Bebidas', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE `cliente` (
  `DNI` char(8) NOT NULL,
  `NOMBRES` varchar(25) NOT NULL,
  `APELLIDOS` varchar(25) NOT NULL,
  `DIRECCION` varchar(35) DEFAULT NULL,
  `CORREO` varchar(40) NOT NULL,
  `NUMEROTEL` varchar(15) NOT NULL,
  `ESTADO` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`DNI`, `NOMBRES`, `APELLIDOS`, `DIRECCION`, `CORREO`, `NUMEROTEL`, `ESTADO`) VALUES('15975388', 'Jose', 'Perez Rojas', 'Av. Mariscal Castilla N1013', 'Jos7895@gmail.com', '+51 987456321', '0');
INSERT INTO `cliente` (`DNI`, `NOMBRES`, `APELLIDOS`, `DIRECCION`, `CORREO`, `NUMEROTEL`, `ESTADO`) VALUES('74196381', 'Jessica ', 'Alva Ruiz', 'Av. Mariscal Castilla N145', '', '', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

DROP TABLE IF EXISTS `detalle`;
CREATE TABLE `detalle` (
  `ID` int(11) NOT NULL,
  `VENTAID` char(15) NOT NULL,
  `PRODUCTOID` char(6) NOT NULL,
  `CANTIDAD` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

DROP TABLE IF EXISTS `producto`;
CREATE TABLE `producto` (
  `ID` char(6) NOT NULL,
  `NOMBRE` varchar(25) NOT NULL,
  `DESCRIPCION` varchar(35) NOT NULL,
  `PRECIO` double NOT NULL,
  `CATEGORIA` char(4) NOT NULL,
  `STOCK` int(7) NOT NULL,
  `FOTO` longblob DEFAULT NULL,
  `ESTADO` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ID`, `NOMBRE`, `DESCRIPCION`, `PRECIO`, `CATEGORIA`, `STOCK`, `FOTO`, `ESTADO`) VALUES('D5EB5E', 'Inka cola', 'Gaseosa 3L', 10.5, 'DFGT', 2000, NULL, '0');
INSERT INTO `producto` (`ID`, `NOMBRE`, `DESCRIPCION`, `PRECIO`, `CATEGORIA`, `STOCK`, `FOTO`, `ESTADO`) VALUES('GHJ7F2', 'Sapolio', '1botella x 750mL.', 7.65, '5A07', 15900, '', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

DROP TABLE IF EXISTS `rol`;
CREATE TABLE `rol` (
  `ID` char(3) NOT NULL,
  `ROL` varchar(30) NOT NULL,
  `ESTADO` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`ID`, `ROL`, `ESTADO`) VALUES('98B', 'EmpleadoMantenimientos', '0');
INSERT INTO `rol` (`ID`, `ROL`, `ESTADO`) VALUES('FGV', 'EmpleadoVentas', '0');
INSERT INTO `rol` (`ID`, `ROL`, `ESTADO`) VALUES('XDF', 'Administrador', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `ID` char(4) NOT NULL,
  `NOMBRES` varchar(25) NOT NULL,
  `APELLIDOS` varchar(25) NOT NULL,
  `USUARIO` varchar(15) NOT NULL,
  `CONTRASENA` varchar(15) NOT NULL,
  `ROLID` char(3) NOT NULL,
  `ESTADO` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID`, `NOMBRES`, `APELLIDOS`, `USUARIO`, `CONTRASENA`, `ROLID`, `ESTADO`) VALUES('8980', 'Alejandro', 'Orosco', 'PHIL4', 'PHIL4', 'FGV', '0');
INSERT INTO `usuario` (`ID`, `NOMBRES`, `APELLIDOS`, `USUARIO`, `CONTRASENA`, `ROLID`, `ESTADO`) VALUES('abcd', 'Edita', 'Chafloque', 'EDITA45', '159', 'XDF', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

DROP TABLE IF EXISTS `venta`;
CREATE TABLE `venta` (
  `ID` char(15) NOT NULL,
  `CLIENTEDNI` char(8) NOT NULL,
  `USUARIOID` char(4) NOT NULL,
  `DESCUENTO` double NOT NULL,
  `FECHA` date NOT NULL,
  `HORA` char(8) NOT NULL,
  `TOTAL` double NOT NULL,
  `ESTADO` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`DNI`);

--
-- Indices de la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `VENTAID` (`VENTAID`),
  ADD KEY `PRODUCTOID` (`PRODUCTOID`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CATEGORIA` (`CATEGORIA`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ROLID` (`ROLID`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `USUARIOID` (`USUARIOID`),
  ADD KEY `CLIENTEID` (`CLIENTEDNI`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalle`
--
ALTER TABLE `detalle`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD CONSTRAINT `detalle_ibfk_1` FOREIGN KEY (`PRODUCTOID`) REFERENCES `producto` (`ID`),
  ADD CONSTRAINT `detalle_ibfk_2` FOREIGN KEY (`PRODUCTOID`) REFERENCES `venta` (`ID`);

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`CATEGORIA`) REFERENCES `categoria` (`ID`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`ROLID`) REFERENCES `rol` (`ID`);

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`CLIENTEDNI`) REFERENCES `cliente` (`DNI`),
  ADD CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`USUARIOID`) REFERENCES `usuario` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
