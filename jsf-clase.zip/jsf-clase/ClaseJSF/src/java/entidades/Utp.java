/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author JUANA
 */
@Entity
@Table(name = "utp")
@NamedQueries({
    @NamedQuery(name = "Utp.findAll", query = "SELECT u FROM Utp u")
    , @NamedQuery(name = "Utp.findByClave", query = "SELECT u FROM Utp u WHERE u.clave = :clave")
    , @NamedQuery(name = "Utp.findByNombre", query = "SELECT u FROM Utp u WHERE u.nombre = :nombre")
    , @NamedQuery(name = "Utp.findByTrimestre", query = "SELECT u FROM Utp u WHERE u.trimestre = :trimestre")
    , @NamedQuery(name = "Utp.findByRequisito", query = "SELECT u FROM Utp u WHERE u.requisito = :requisito")})
public class Utp implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "clave")
    private Integer clave;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Column(name = "trimestre")
    private int trimestre;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "requisito")
    private String requisito;

    public Utp() {
    }

    public Utp(Integer clave) {
        this.clave = clave;
    }

    public Utp(Integer clave, String nombre, int trimestre, String requisito) {
        this.clave = clave;
        this.nombre = nombre;
        this.trimestre = trimestre;
        this.requisito = requisito;
    }

    public Integer getClave() {
        return clave;
    }

    public void setClave(Integer clave) {
        this.clave = clave;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTrimestre() {
        return trimestre;
    }

    public void setTrimestre(int trimestre) {
        this.trimestre = trimestre;
    }

    public String getRequisito() {
        return requisito;
    }

    public void setRequisito(String requisito) {
        this.requisito = requisito;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (clave != null ? clave.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Utp)) {
            return false;
        }
        Utp other = (Utp) object;
        if ((this.clave == null && other.clave != null) || (this.clave != null && !this.clave.equals(other.clave))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Utp[ clave=" + clave + " ]";
    }
    
}
